---
name: sound-healing-studio
description: Turn raw Wellness By Nicole sound-healing event footage into polished sizzle reels, short social clips, highlight selections, voiceover-ready edits, and reusable media assets. Use when the user asks to review event videos, find highlights, create reels, make promo videos, cut vertical/landscape variants, prepare Nicole narration, or organize large raw video files for editing.
---

# Wellness By Nicole Sound Healing Studio

Use this skill as a media producer/editor for Wellness By Nicole Q. The goal is to turn authentic event footage into warm, elevated, grounded promotional content without fabricating what happened.

## Core principles

- Preserve real people, real sound-healing moments, and the real environment.
- Do not generate fake participant reactions or alter what attendees appeared to experience.
- Prefer real footage over generative replacement footage.
- Avoid exposing private conversations, phone screens, license plates, attendee contact information, or other personal data.
- Do not publish or upload anything publicly unless explicitly requested.
- Work non-destructively: never overwrite raw media.
- Keep all generated assets under the studio workspace described below.

## Default studio layout

When starting a project, create or use:

```text
media-studio/
  raw/                 # untouched source videos
  proxies/             # smaller analysis copies
  frames/              # contact sheets / thumbnails
  selects/             # chosen source segments
  audio/               # narration, bowls, ocean, music stems
  captions/            # SRT/VTT/transcripts
  branding/            # logos, approved graphics, fonts references
  projects/            # edit decision lists and project JSON
  output/
    landscape/
    vertical/
    square/
  archive/
```

Never move or modify files inside `raw/` unless the user explicitly asks.

## Step 1 — Ingest and inventory

1. Scan `media-studio/raw/` for video files.
2. Use `ffprobe` to record filename, duration, resolution, frame rate, codecs, audio channels, and file size.
3. Write `media-studio/projects/media-inventory.json`.
4. For videos larger than ~1 GB or longer than ~10 minutes, create analysis proxies rather than repeatedly analyzing originals.

Run:

```bash
python .cline/skills/sound-healing-studio/scripts/prepare_media.py media-studio/raw media-studio/proxies media-studio/frames
```

The script creates lower-resolution analysis proxies and contact sheets while preserving originals.

## Step 2 — Analyze footage for selects

Prefer GLM-5V-Turbo or another video-capable multimodal model when available. For every source clip, identify timecoded candidate moments and score them.

Look for:

- Nicole actively facilitating
- crystal bowls being struck or played
- close-ups of bowls and instruments
- wide group shots with beach/ocean/nature context
- attendees settling in, resting, breathing, or looking peaceful
- authentic smiles or connection before/after the session
- sunset, surf, sky, candles, blankets, instruments, hands, textures
- natural transitions: walking in, arranging bowls, striking a bowl, waves, closing moments
- useful natural audio: clear bowl resonance, ocean, wind without distortion, short Nicole speaking moments

Avoid or heavily downgrade:

- severe shake or accidental camera movement
- obstructed views
- unusable wind noise or clipping
- duplicate/repetitive angles
- frames that make attendees look awkward or vulnerable
- private conversations
- shots dominated by phones, bags, parking lots, setup clutter unless needed for story
- anyone who appears to object to being filmed

Create `media-studio/projects/selects.json` with:

```json
{
  "source": "event-01.mp4",
  "start": "00:04:12.000",
  "end": "00:04:18.500",
  "score": 9,
  "shot_type": "wide-group",
  "reason": "Nicole and full group visible with ocean behind them; stable composition",
  "audio": "usable-natural"
}
```

Before final editing, summarize the strongest 15–25 candidate moments for the user when practical.

## Step 3 — Choose the story

Default deliverables for a full event:

1. **45-second landscape sizzle reel (16:9)** — website, YouTube, Facebook.
2. **30-second vertical reel (9:16)** — Instagram Reels, TikTok, Shorts.
3. **15-second vertical teaser (9:16)** — quick promotional post/story.

Default emotional arc:

1. **Arrival / place** — establish beach, room, bowls, atmosphere.
2. **Invitation** — Nicole preparing or beginning.
3. **Immersion** — strongest bowl-play and participant relaxation shots.
4. **Connection** — group, smiles, shared environment.
5. **Close / CTA** — Nicole, bowls, sunset/ocean, brand mark, booking or next-event CTA.

Do not make every reel a frantic montage. Wellness content should breathe. Favor 1.5–4 second shots, with occasional longer resonance moments.

## Step 4 — Edit decision list

Write `media-studio/projects/<project-name>-edl.json` before rendering. Each edit should include:

- source file
- in/out timecodes
- target timeline in/out
- crop/orientation instruction
- whether natural audio is used
- transition type (default: cut or short dissolve)
- optional text overlay

Keep effects restrained. Avoid gimmicky wipes, excessive zooms, rapid glitch cuts, and overdone AI effects.

## Step 5 — Audio treatment

Priorities:

1. Preserve exceptional bowl resonance and ocean ambience where clean.
2. Use narration only when it adds context; do not talk continuously over the most beautiful sound-healing moments.
3. If using music, keep it subtle and licensed/approved. Duck it under bowls and voice.
4. Normalize final loudness and avoid clipping.

For Nicole narration:

- Prefer the approved private Nicole HeyGen voice when available.
- Tone: warm, grounded, confident, inviting; not sleepy or theatrical.
- Pace: natural, with breathing room.
- Keep claims experiential and non-medical unless specifically approved.

## Step 6 — Branding and copy

Brand tone: warm, safe, elevated, grounded.

Default on-screen copy should be short. Examples:

- `Sound Healing by the Sea`
- `Pause. Breathe. Receive.`
- `Wellness By Nicole Q`
- `Join the next experience`

Do not clutter the video with paragraphs.

If a CTA is needed, prefer a simple closing card with the approved website, booking link, or event date supplied by the user.

## Step 7 — Render

Use FFmpeg or Remotion for deterministic final assembly.

Baseline exports:

- Landscape: H.264 MP4, 1920x1080, 30 fps, AAC audio
- Vertical: H.264 MP4, 1080x1920, 30 fps, AAC audio
- Web preview: H.264 MP4, 1280x720 when a lighter review file is useful

For vertical crops, reframe around Nicole, bowls, and faces. Do not simply center-crop if it cuts off the important action.

## Step 8 — Quality control

Before delivery verify:

- no black frames or accidental freeze frames
- no clipped captions or text outside safe zones
- no unexpected private/personal information visible
- voice/music/natural sound are balanced
- no audio peaks above 0 dBFS
- correct duration and orientation
- CTA spelling and brand name are correct
- raw files remain untouched

Report:

- output filename and duration
- aspect ratio
- source files used
- any shots omitted for privacy/quality reasons
- whether narration, music, and natural audio were included

## Large-file strategy

For multi-GB source videos:

1. Do not duplicate originals unnecessarily.
2. Create 720p proxies at modest bitrate for analysis.
3. Split proxies into ~5-minute chunks when the model/tool cannot reliably inspect the whole file.
4. Generate contact sheets at useful intervals for fast visual triage.
5. Perform final cuts from the original files using the timecodes selected from proxies.
6. If proxy and original time bases differ, validate the first/last select against the original before bulk rendering.

## Generative AI policy for this studio

Generative video/image tools may be used for:

- abstract branded intros/outros
- tasteful backgrounds
- title-card motion
- non-documentary decorative elements

They should not be used to fabricate attendees, reactions, practitioner actions, or an event that did not occur.

## Common user requests

- "Make a sizzle reel from last night's sound bath"
- "Find the best 20 moments in these event videos"
- "Create a 30-second Instagram reel"
- "Make a teaser for Nicole's next sound healing"
- "Use Nicole's voice for a short narration"
- "Cut this 40-minute event into highlights"
- "Prepare the raw footage for GLM review"

For detailed operating guidance, read `docs/studio-workflow.md`.
