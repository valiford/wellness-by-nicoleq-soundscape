#!/usr/bin/env python3
import json, subprocess, sys
from pathlib import Path

VIDEO_EXTS = {'.mp4','.mov','.m4v','.avi','.mkv','.webm'}

def sh(cmd):
    return subprocess.run(cmd, check=True, text=True, capture_output=True)

def probe(path):
    p = sh(['ffprobe','-v','error','-show_entries','format=duration,size:stream=index,codec_type,codec_name,width,height,r_frame_rate,channels','-of','json',str(path)])
    data = json.loads(p.stdout)
    return data

def main():
    if len(sys.argv) != 4:
        print('Usage: prepare_media.py RAW_DIR PROXY_DIR FRAMES_DIR')
        sys.exit(2)
    raw = Path(sys.argv[1]); proxies = Path(sys.argv[2]); frames = Path(sys.argv[3])
    proxies.mkdir(parents=True, exist_ok=True); frames.mkdir(parents=True, exist_ok=True)
    inventory=[]
    for src in sorted(raw.rglob('*')):
        if not src.is_file() or src.suffix.lower() not in VIDEO_EXTS: continue
        meta=probe(src)
        duration=float(meta.get('format',{}).get('duration') or 0)
        out=proxies/(src.stem+'-proxy.mp4')
        if not out.exists():
            subprocess.run(['ffmpeg','-y','-i',str(src),'-vf','scale=-2:720','-c:v','libx264','-preset','veryfast','-crf','27','-c:a','aac','-b:a','96k',str(out)],check=True)
        sheet=frames/(src.stem+'-contact.jpg')
        if not sheet.exists():
            interval=max(10,int(duration/20)) if duration else 30
            subprocess.run(['ffmpeg','-y','-i',str(out),'-vf',f'fps=1/{interval},scale=320:-1,tile=5x4','-frames:v','1',str(sheet)],check=False)
        inventory.append({'source':str(src),'proxy':str(out),'contact_sheet':str(sheet),'probe':meta})
    project_dir=raw.parent/'projects'; project_dir.mkdir(exist_ok=True)
    inv=project_dir/'media-inventory.json'; inv.write_text(json.dumps(inventory,indent=2))
    print(f'Prepared {len(inventory)} video(s). Inventory: {inv}')

if __name__=='__main__': main()
