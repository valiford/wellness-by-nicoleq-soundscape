# Sound Healing Studio Workflow

## Recommended operating pattern

### A. Drop footage
Copy original videos into `media-studio/raw/`. Keep originals read-only when possible.

### B. Prepare proxies
Run the bundled `prepare_media.py` script. It uses ffprobe/ffmpeg to inventory media, generate 720p proxy files, and create contact sheets.

### C. Ask Cline/GLM for selects
Example prompt:

> Review the new footage in `media-studio/proxies/` using the sound-healing-studio skill. Build a ranked select list for a 45-second Wellness By Nicole Q event reel. Favor Nicole facilitating, beautiful bowl close-ups, wide group/ocean shots, peaceful participant moments, and clean natural bowl audio. Do not edit yet; show me the proposed story and strongest selects first.

### D. Approve story
Once the selects look good:

> Build the 45-second landscape master and 30-second vertical reel from the approved selects. Use original media for final rendering. Preserve strong bowl/ocean sound, use restrained transitions, and add a simple Wellness By Nicole Q closing card.

### E. Add narration if wanted
Use narration selectively. Sound healing footage often works best when viewers can actually hear the bowls.

Suggested structure for a 30-second reel:

- 0–4 sec: natural ocean / establishing shot
- 4–10 sec: Nicole / bowls
- 10–20 sec: immersive sequence with natural bowl audio
- 20–26 sec: group / atmosphere
- 26–30 sec: brand + CTA

## File-size guidance

- Under ~1 GB / under ~10 min: direct review may be practical depending on model/tool.
- Larger files: use proxies.
- Very long sessions: split proxy into 5-minute chunks for systematic review.
- Final export always comes from originals.

## Visual score rubric

Score each candidate 1–10 using:

- 0–2 composition/stability
- 0–2 Nicole/action relevance
- 0–2 emotional/atmospheric value
- 0–2 brand usefulness
- 0–2 audio usefulness

Use 8–10 shots as primary selects, 6–7 as alternates, below 6 only if needed for continuity.

## Suggested reel styles

### Calm cinematic
Slower cuts, bowl resonance, ocean ambience, soft titles. Best default.

### Community energy
More arrivals, smiles, group interaction, slightly quicker pacing. Best for event promotion.

### Nicole practitioner spotlight
Focus on Nicole, instruments, guidance, setup, and short voiceover. Best for service marketing.

### Event recap
Chronological mini-story from setup → gathering → immersion → close. Best after a specific event.

## Privacy review

Before final render, inspect selected clips for:

- children/minors
- private conversations
- identifying screens/documents
- license plates
- wardrobe or poses that might embarrass attendees in a promotional context
- people who appear to be avoiding the camera

When uncertain, choose a different shot.
